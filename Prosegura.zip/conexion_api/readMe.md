Recomendaciones:

    En la llamada de las direcciones de SIMI colocar como protocolo Https://


Orden a la hora de llamar los archivos del API

    Inmuebles Destacados
    1. token_api.js
    2. validadores.js
    3. inmuebles_destacados.js

    Listar Inmuebles
    1. token_api.js
    2. validadores.js
    3. modelo_inmueble.js
    4. listarInmuebles.js
    5. buscador.js

    Detalle Inmueble
    1. token_api.js
    2. validadores.js
    3. modelo_inmueble.js
    4. detalle_inmueble.js
    5. similares.js

    Buscador pagina de Inicio
    1.token_api.js
    2. validadores.js
    3. buscador.js

Como nombrar los id para el buscador.
    Los nombres de los campos del buscador deben terminar con la palabra "_buscar" y la palabra debe ser singular

    codigo_buscar
    tipo_inmueble_buscar
    tipo_gestion_buscar
    ciudad_buscar
    barrio_buscar
    precio_minimo_buscar
    precio_maximo_buscar
    banos_buscar
    alcobas_buscar

    cualquier campo adicional debe terminar en "_buscar"

Variables para enviar como parametros en la url a la hora de buscar, se utiliza como protocolo las primeras letras de cada palabra

    co=codigo
    in= tipo de INMUEBLE
    ge= gestion
    ci=ciudad
    bar=barrios
    al=alcobas
    ban=baños
    min = precio minimo
    max = precio maximo






