<?php $page ="Inicio";
require("seguridad.php"); 
require_once("conexion.php");
include 'layout/layout.php';
?>
<div class="fondo_imagen">

</div>


<?php include 'layout/layoutFooter.php';?>
